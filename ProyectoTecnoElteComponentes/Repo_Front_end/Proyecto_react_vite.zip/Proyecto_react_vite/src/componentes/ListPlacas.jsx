import { Button } from 'bootstrap';
import React, { useEffect } from 'react'
import {useState} from 'react'
import * as API from '../servicios/servicios'

export function ListPlacas(){
  const [componentes, setComponentes] = useState([]);

  return(
    <>
<div className="card">
  <div className="card-header">
    Listado de Placas
  </div>
  <div className="card-body">
<table className="table">
<thead>
    <tr>
     <th>Nombre</th>
     <th>Cantidad</th>
     <th> Precio</th>
     <th>&nbsp;</th>
    </tr>
</thead>

     <td> 
        <div className='btn-group' role='group' aria-aria-label='' >
        <button onclick="function" type="button" className="btn btn-warning">Editar</button>
        <button onclick="function" type="button" className="btn btn-danger">Eliminar</button>
        </div>
        <button onclick="functionToExecute()" type="button" className="btn btn-secondary"> Volver</button>
     </td>
     
</table>
</div>
 </div>
</>
 )}