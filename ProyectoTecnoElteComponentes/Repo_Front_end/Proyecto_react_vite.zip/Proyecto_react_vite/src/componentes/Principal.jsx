//import React from 'react';
export function Principal(){
    return(
      <>
        <div> 
          <h1>Bienvenido a Tecno-Elite Componentes</h1> 
        </div>

      </>
    )
}