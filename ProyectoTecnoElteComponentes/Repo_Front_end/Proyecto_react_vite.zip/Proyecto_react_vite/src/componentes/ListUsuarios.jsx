import React, { useEffect } from 'react'
import {useState} from 'react'
import * as API from "../servicios/servicios"

export function ListUsuarios(){
    const  [usuarios, setUsuarios] = useState([]);

    useEffect(()=>{
        API.getUsuarios().then(setUsuarios)
      },[]);

return(  
    <div className="card">
        <div class="card-header">
            Listado de Usuarios
        </div>
      {/*} {
        mensajeError?
        <div class="alert alert-warning" role="alert">
        {mensajeError}
        </div>:''

       }*/}
    <div className="card-body">
    <table className="table">
   <thead>
    <tr>
     <th>ID</th>
     <th>Nombre</th>
     <th> Apellido</th>
     <th>DNI</th>
     <th>Sexo</th>
     <th>Domicilio </th>
     <th> Estado Civil</th>
     <td> Estado </td>
     <th>&nbsp;</th>
     </tr>
  </thead>
  {/*<tbody>
    {usuarios.map((usuario)=>(
    <tr key={usuario.id}> 
      <td scope="row">{usuario.id}</td>
      <td {usuario.nombre}</td>
      <td {usuario.apellido}</td>
      <td {usuario.dni}</td>
      <td {usuario.sexo}</td>
      <td {usuario.domicilio}</td>
      <td {usuario.estado civil}</td>
      <td>
         <div className="btn-group" role="group" aria-label="">
         <button onClick={() => bajaUsuario(usuario.id)} type="button" className="btn btn-danger"> Dar de Baja </button>
         <button onClick={() => altaUsuario(usuario.id)} type="button" className="btn btn-success"> Dar de Alta </button>
    )

    }
  </tbody>*/}
       
    <td>
        <div className="btn-group" role="group" aria-label=''>
            <button type="button" className="btn btn-warning">Editar</button>
            <button type="button" className="btn btn-danger">Eliminar</button>
        </div>
    </td>
    <button onclick="functionToExecute()" type="button" className="btn btn-secondary"> Volver </button>
    </table>
    </div>
    </div>
    

) }
