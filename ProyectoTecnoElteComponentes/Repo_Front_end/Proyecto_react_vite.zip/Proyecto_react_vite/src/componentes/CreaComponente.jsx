import React from "react"
export function CreaComponente(){
  return(
    <>
       <div className="card">
        <div className="card-header">
            Crear Componente
        </div>
         <div className="card-body">
          <div className="form-group">
                <label for="">Añadir Componentes</label>
                <input type="text" name="" id="" className="form-control" placeholder="" aria-describedby="helpId"/>
                    <small id="helpId" class="text-muted">&nbsp;</small>
    </div>
            <div className="form-group">
                <button type="button" className="btn btn-primary"> Guardar</button>
                <button type="button" className="btn btn-secondary"> Volver al listado</button> 
            </div>
        </div>
        </div>
    <div className="card-footer text-muted">
        Tecno-Elite Componentes
        </div>
        </>
        ) 
}