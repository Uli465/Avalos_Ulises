const API_URL ='http://localhost:3300'

//trae los componentes
export async function getComponentes() {
    try {
        const response = await fetch(`${API_URL}/componentes`);
        const data = await response.json();
        return data;
    }catch(error){
     console.log('Nuestro error', error);
    }    
    
}
//trae los ususarios
export async function getUsuarios() {
    try {
        const response = await fetch(`${API_URL}/usuarios`);
        const data = await response.json();
        return data;
    }catch(error){
    console.log('Nuestro error', error);
    }  
    
}
/*export async function BajaUsuario(id_usuario) {
    const requestOptions={
        method: 'PUT',
        headers:{
            'Content-Type': 'application/json',}

        }
    };

    
    try {
        const response = await fetch(`${API_URL}/bajausuario/${id_usuario}`, requestOptions)
        const data = await response.json();
        return data;
    }catch(e){
    alert('No se puede conectar con el servidor')
    }  */

    /*export async function AltaUsuario(id_usuario) {
        const requestOptions={
            method: 'PUT',
            headers:{
                'Content-Type': 'application/json',}
    
            }
        };
    
        
        try {
            const response = await fetch(`${API_URL}/altausuario/${id_usuario}`, requestOptions)
            const data = await response.json();
            return data;
        }catch(e){
        alert('No se puede conectar con el servidor')
        }  */
    
