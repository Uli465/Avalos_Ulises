
import {Routes,Route, Link } from 'react-router-dom'
import React from 'react';
//import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

//import './App.css'
import { ListPlacas } from './componentes/ListPlacas'
import { CreaComponente } from './componentes/CreaComponente'
import { Principal } from './componentes/Principal'
import { ListUsuarios } from './componentes/ListUsuarios'
import { CrearUsuario } from './componentes/CrearUsuario'
import {ListPuentesh} from './componentes/ListPuentesh'
import {ListBaterias} from './componentes/ListBaterias'

function App() {
  return (
    <>
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
 <a className="navbar-brand" href="#">Sistema</a>
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>
  <div className="collapse navbar-collapse" id="navbarNavDropdown">
    <ul className="navbar-nav">
      <li className="nav-item active">
        <Link className="nav-link" to={'/'}>Inicio</Link>
      </li>
      
      <li className="nav-item dropdown">

        <a className="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Categorias
        </a>
        <div className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
         <Link className="dropdown-item" to={'/listar_placas'}>Placas</Link>
         <Link className="dropdown-item" to={'/listar_puenteh'}>Puentes H</Link>
         <Link className="dropdown-item" to={'/listar_baterias'}>Baterias</Link>
          <Link className="dropdown-item" to={'/crear_componentes'}> Crear Componentes</Link>
        </div>
        </li>
        
        

      <li className="nav-item dropdown">
        <a className="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Usuarios
        </a>
        <div className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <Link className="dropdown-item" to={'/listar_usuarios'}>Listar Usuarios</Link>
          <Link className="dropdown-item" to={'/crear_usuarios'}> Crear Usuarios</Link>
        </div>
      </li>
  
    </ul> 
  </div>
</nav>

      <div className='container'>
      <Routes>
      <Route path='/' element={<Principal/>}></Route>
      <Route path='/listar_placas' element={<ListPlacas/>}></Route>
      <Route path='/listar_puntesh' element={<ListPuentesh/>}></Route>
      <Route path='/listar_baterias' element={<ListBaterias/>}></Route>

      <Route path='/crear_componentes' element={<CreaComponente/>}></Route>
      <Route path='/listar_usuarios' element={<ListUsuarios/>}></Route>
      <Route path='/crear_usuarios' element={<CrearUsuario/>}></Route>  
     </Routes>
      </div>
    </>
  )


}

export default App