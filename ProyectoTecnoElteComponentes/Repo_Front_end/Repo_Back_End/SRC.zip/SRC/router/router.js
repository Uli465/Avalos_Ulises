const express= require('express');
const router = express();
////////libreria que utiizamos para la incriptacion de los password
const bcrypt= require('bcrypt');
///// Libreira que utilizaremos para la generacion de nuestro token
const jwt=require('jsonwebtoken');


//se incluye archivo de coneccion
const mysqlConeccion= require('../database/database');
const { token } = require('morgan');

//se incluye archivo de coneccion
//Rutas para mi aplicacion
router.get('/', (request,respuesta)=>{
    respuesta.send('Pantalla inicio de nuestra aplicacion');
    
})

//////////////CLIENTE//////////////
//////////////CLIENTE//////////////
//////////////CLIENTE//////////////
//////////////CLIENTE//////////////


//DEVUELVE LOS CLIENTES ACTIVOS 
router.get('/cliente/alta', (request,respuesta)=>{
    //respuesta.send('listado de usuarios');
    const query= 'select * from cliente where estado="A"';
    mysqlConeccion.query(query, (err, rows)=>{
        if(!err){
            respuesta.json(rows);
        }else{
            console.log(err)
        }
    })
});

//DEVUELVE LOS CLIENTES DE BAJA
router.get('/cliente/baja', (request,respuesta)=>{
    //respuesta.send('listado de usuarios');
    const query= 'select * from cliente where estado="B"';
    mysqlConeccion.query(query, (err, rows)=>{
        if(!err){
            respuesta.json(rows);
        }else{
            console.log(err)
        }
    })
});

//DEVUELVE TODOS LOS CLIENTES
router.get('/cliente/todos', (request,respuesta)=>{
    //respuesta.send('listado de usuarios');
    const query= 'select * from cliente';
    mysqlConeccion.query(query, (err, rows)=>{
        if(!err){
            respuesta.json(rows);
        }else{
            console.log(err)
        }
    })
});


//DEVUELVE LOS DATOS DE UN CLIENTE DEL CUAL SE RECIBE EL ID
router.get('/cliente/:idcliente', verificarToken, (request, respuesta)=>{
    const { idcliente } = request.params;
    jwt.verify(request.token,'uliseskey', (err, valido)=>{

        if(err){
            respuesta.sendStatus(403);

        }else{
            mysqlConeccion.query('SELECT * FROM cliente WHERE idcliente = ?', [idcliente], (err, rows) => {

              
                if(!err){
                    if(rows.length!=0){
                    respuesta.json(rows);
                    }else{
                        respuesta.json(
                            {
                                exito: false,
                                mensaje: "El ID del alumno no existe en la base de datos."
    
                            });

                    }
                }else{
                    console.log(err)
                }
            })
        }
        

    })

   
});

//METODO PARA INSERTAR CLIENTE POR EL METODO POST
router.post('/cliente', (request,respuesta)=>{
    const {nombre, apellido, dni, telefono, direccion, ciudad, departamento, codigoPostal, pais} = request.body
    let query= `INSERT INTO cliente (nombre, apellido, dni, telefono, direccion, ciudad, departamento, codigoPostal, pais, estado, Fecha_creacion) VALUES ('${nombre}', '${apellido}', '${dni}', '${telefono}', '${direccion}', '${ciudad}', '${departamento}', '${codigoPostal}', '${pais}','A', NOW())`;
    mysqlConeccion.query(query, (err, registros)=>{
        if(!err){
            respuesta.json('Se inserto correctamente nuestro cliente:'+nombre+''+apellido);
        }else{
            console.log(err)
            respuesta.send('EL error es: '+err);
        }
    })
    //respuesta.send('Llega el mensaje');

});

//METODO PARA , MODOFICAR USUARIOS A TRAVES DEL PUT (HAY QUE MODIFICAR TODOS LOS CAMPOS O LOS VACIOS LOS PONE COMO UNDEFINDED)
/*router.put('/cliente/:idcliente', (request,respuesta)=>{
    //asigna a idiusuario el valor que recibepor el parametro
    let idusuario = request.params.idusuario;
    //asigna el valor que recibe en el body
    const {nombre, Apellido, Dni, Telefono, Direccion, Ciudad, Departamento, CodigoPostal, Pais, Email}  = request.body
    let query= `UPDATE usuarios SET nombre='${nombre}', Apellido='${Apellido}',Dni='${Dni}',Telefono='${Telefono}',Direccion='${Direccion}',Ciudad='${Ciudad}',Departamento='${Departamento}', CodigoPostal='${CodigoPostal}', Pais='${Pais}', Email='${Email}', Fecha_modificacion= NOW() WHERE idusuario='${idusuario}'`;
    mysqlConeccion.query(query, (err, registros)=>{
        if(!err){
            respuesta.send('El ID que vamos a cambiar es :' +idusuario+ 'y vamos a cambiar muchos campos');

        }else{
            console.log(err)
            
        }
    })
})*/

//METODO PARA , MODFICAR CLIENTES A TRAVES DEL PUT (SE PUEDE MODIFICAR TODOS O ALGUNOS CAMPOS)
router.put('/cliente/:idcliente', (request, respuesta) => {
    // Asigna a idusuario el valor que recibe por el parámetro
    let idcliente = request.params.idusuario;
  
    // Asigna el valor que recibe en el body
    const {nombre, apellido, dni, telefono, direccion, ciudad, departamento, codigoPostal, pais} = request.body;
    
    let query = 'UPDATE cliente SET ';
  
    let campos = [];
  
    if (nombre !== undefined) {
      campos.push(`nombre='${nombre}'`);
    }
  
    if (apellido !== undefined) {
      campos.push(`apellido='${apellido}'`);
    }
  
    if (dni !== undefined) {
      campos.push(`dni='${dni}'`);
    }
  
    if (telefono !== undefined) {
      campos.push(`telefono='${telefono}'`);
    }
  
    if (direccion !== undefined) {
      campos.push(`direccion='${direccion}'`);
    }
  
    if (ciudad !== undefined) {
      campos.push(`ciudad='${ciudad}'`);
    }
  
    if (departamento !== undefined) {
      campos.push(`departamento='${departamento}'`);
    }
  
    if (codigoPostal !== undefined) {
      campos.push(`codigoPostal='${codigoPostal}'`);
    }
  
    if (pais !== undefined) {
      campos.push(`pais='${pais}'`);
    }
  
    query += campos.join(', ');
    query += ', fecha_modificacion=NOW() ';
    query += `WHERE idcliente='${idcliente}'`;
  
    mysqlConeccion.query(query, (err, registros) => {
      if (!err) {
        respuesta.send(`Se ha actualizado el cliente con id ${idcliente}`);
      } else {
        console.log(err);
        respuesta.status(500).send('Ha ocurrido un error al actualizar el cliente');
      }
    });
});
  





//////////////PRODUCTOS//////////////
//////////////PRODUCTOS//////////////
//////////////PRODUCTOS//////////////
//////////////PRODUCTOS//////////////


//DEVUELVE TODOS LOS PRODUCTOS DE UNA CATEGORIA ESPECIFICA  

router.get('/productos/:idcategoria', (request, respuesta) => {
    const idcategoria = request.params.idcategoria;
    const query = `
      SELECT p.*
      FROM productos p
      INNER JOIN categoria_producto cp ON p.idproducto = cp.id_producto
      WHERE cp.id_categoria = ?
    `;
    mysqlConeccion.query(query, [idcategoria], (err, rows) => {
      if (!err) {
        respuesta.json(rows);
      } else {
        console.log(err);
        respuesta.status(500).send('Ha ocurrido un error al obtener los productos');
      }
    });
  });
  



//DEVUELVE TODOS LOS PRODUCTOS
router.get('/productos', (request,respuesta)=>{
    mysqlConeccion.query('select * from productos', (err, rows)=>{
        if(!err){
            respuesta.json(rows);
        }else{
            console.log(err)
        }
    })
});

//DEVUELVE LOS DATOS DE UN PRODUCTO PUNTUAL
router.get('/productos/:idproducto', (request, respuesta) => {
    const {idproducto} = request.params;
    mysqlConeccion.query('select * from productos where idproducto=?',[idproducto], (err, registros)=>{
        if(!err){
            respuesta.json(registros);
        }else{
            console.log(err)
        }
    })
});

//METODO PARA INGRESAR NUEVO PRODUCTO POR EL METODO POST
router.post('/productos', (request,respuesta)=>{
    console.log(request.body)
    const { nombre } = request.body
    const { Descripcion } = request.body
    const { Cantidad } = request.body
    const { Precio } = request.body
    const { id_categoria } = request.body
    let query= `INSERT INTO productos (nombre, Descripcion, Cantidad, Precio, id_categoria) VALUES ('${nombre}', '${Descripcion}', ${Cantidad}, ${Precio}, ${id_categoria})`;

    //respuesta.send('Funciona el endpoint y el valor que recibi es: '+nombre, +Descripcion, +Cantidad, +Precio, +id_categoria);
    mysqlConeccion.query(query, (err, registros)=>{
        if(!err){
            respuesta.json(registros);
        }else{
            console.log(err)
        }
    })

});


//METODO PARA MODIFICAR PRODUCTO A TRAVES DEL METODO PUT (falta)
/*router.put('/productos/:idproducto', (request,respuesta)=>{
    //asigna a idcategoria el valor que recibepor el parametro
    let idcategoria = request.params.idcategoria;
    //asigna a nombrenuevo:categoria nuevo el valor que recibe en el body,nombre
    let nombrenuevo_categoria = request.body.nombre 
    let query= `UPDATE categorias SET nombre='${nombrenuevo_categoria}' WHERE idcategoria='${idcategoria}'`;
    mysqlConeccion.query(query, (err, registros)=>{
        if(!err){
            respuesta.send('El ID que vamos a cambiar es :' +idcategoria+ 'y vamos a cambiar el nombre a: ' +nombrenuevo_categoria);

        }else{
            console.log(err)
            
        }
    })

});*/

//METODO PARA MODFICAR PRODUCTOS A TRAVES DEL PUT (SE PUEDE MODIFICAR TODOS O ALGUNOS CAMPOS)

router.put('/productos/:idproducto', (request, respuesta) => {
    // Asigna a idproducto el valor que recibe por el parámetro
    let idproducto = request.params.idproducto;
  
    // Asigna el valor que recibe en el body
    const {nombre, descripcion, cantidad, precio} = request.body;
    
    
    let query = 'UPDATE productos SET ';
  
    let campos = [];
  
    if (nombre !== undefined) {
      campos.push(`nombre='${nombre}'`);
    }
  
    if (descripcion !== undefined) {
      campos.push(`descripcion='${descripcion}'`);
    }
  
    if (cantidad !== undefined) {
      campos.push(`cantidad='${cantidad}'`);
    }
  
    if (precio !== undefined) {
      campos.push(`precio='${precio}'`);
    }
  
    query += campos.join(', ');
    query += `WHERE idproducto='${idproducto}'`;
  
    mysqlConeccion.query(query, (err, registros) => {
      if (!err) {
        respuesta.send(`Se ha actualizado el producto con id ${idproducto}`);
      } else {
        console.log(err);
        respuesta.status(500).send('Ha ocurrido un error al actualizar el producto');
      }
    });
  });



//////////////CATEGORIAS//////////////
//////////////CATEGORIAS//////////////
//////////////CATEGORIAS//////////////
//////////////CATEGORIAS//////////////

// MUESTRA TODAS LAS CATEGORIAS
router.get('/categorias', (request,respuesta)=>{
    mysqlConeccion.query('select * from categorias', (err, rows)=>{
        if(!err){
            respuesta.json(rows);
        }else{
            console.log(err)
        }
    })
});

//metodo para modificar categorias a traves de post
/*router.put('/categorias/:idcategoria', (request,respuesta)=>{
    //asigna a idcategoria el valor que recibepor el parametro
    let idcategoria = request.params.idcategoria;
    //asigna a nombrenuevo:categoria nuevo el valor que recibe en el body,nombre
    let nombrenuevo_categoria = request.body.nombre 
    let query= `UPDATE categorias SET nombre='${nombrenuevo_categoria}' WHERE idcategoria='${idcategoria}'`;
    mysqlConeccion.query(query, (err, registros)=>{
        if(!err){
            respuesta.send('El ID que vamos a cambiar es :' +idcategoria+ 'y vamos a cambiar el nombre a: ' +nombrenuevo_categoria);

        }else{
            console.log(err)
            
        }
    })

});*/

//METODO PARA MODIFICAR UNA CATEGORIA POR EL METODO PUT

router.put('/categorias/:idcategoria', (request, respuesta) => {
    // Asigna a idcategoria el valor que recibe por el parámetro
    let idcategoria = request.params.idcategoria;
  
    // Asigna el valor que recibe en el body
    const {nombre, descripcion} = request.body;
    
    
    let query = 'UPDATE categorias SET ';
  
    let campos = [];
  
    if (nombre !== undefined) {
      campos.push(`nombre='${nombre}'`);
    }
  
    if (descripcion !== undefined) {
      campos.push(`descripcion='${descripcion}'`);
    }
  
    query += campos.join(', ');
    query += `WHERE idcategoria='${idcategoria}'`;
  
    mysqlConeccion.query(query, (err, registros) => {
      if (!err) {
        respuesta.send(`Se ha actualizado la categoria con id ${idcategoria}`);
      } else {
        console.log(err);
        respuesta.status(500).send('Ha ocurrido un error al actualizar la categoria');
      }
    });
  });



//METODO PARA INSERTAR NUEVA CATEGORIA POR EL METODO POST

router.post('/categorias/nueva', (request, respuesta) => {
    const {nombre, descripcion} = request.body;
    
    let query = `INSERT INTO categorias (nombre, descripcion) VALUES ('${nombre}', '${descripcion}')`;
  
    mysqlConeccion.query(query, (err, registros) => {
      if (!err) {
        respuesta.send(`Se ha insertado la categoría ${nombre} correctamente`);
      } else {
        console.log(err);
        respuesta.status(500).send('Ha ocurrido un error al insertar la categoría');
      }
    });
  });
  




//////////////USUARIO//////////////
//////////////USUARIO//////////////
//////////////USUARIO//////////////
//////////////USUARIO//////////////

//MUESTRA TODOS LOS USUARIOS
router.get('/usuarios', verificarToken, (request,respuesta)=>{

    just.verify(request.token,'uliseskey', (err,valido)=>{

        if(err){
            respuesta.sendStatus(403);

        }else{
            mysqlConeccion.query('select * from usuarios', (err, registros)=>{
                if(!err){
                    respuesta.json(registros)
        
                }else{
                    console.log(err)
                    
                }
            })

        }
        

    })


   
    //respuesta.send('El endpoint esta llegando correctamente');
})


//MODIFICAR DATOS DE USUARIO

router.put('/usuarios/:idusuario', (request, respuesta) => {
    // Asigna a idusuario el valor que recibe por el parámetro
    let idusuario = request.params.idusuario;
  
    // Asigna el valor que recibe en el body
    const {estado, username, apellido_nombre, email, password} = request.body;
  
    let query = 'UPDATE usuarios SET ';
  
    let campos = [];
  
    if (estado !== undefined) {
      campos.push(`estado='${estado}'`);
    }
  
    if (username !== undefined) {
      campos.push(`username='${username}'`);
    }
  
    if (apellido_nombre !== undefined) {
      campos.push(`apellido_nombre='${apellido_nombre}'`);
    }
  
    if (email !== undefined) {
      campos.push(`email='${email}'`);
    }
  
    if (password !== undefined) {
      campos.push(`password='${password}'`);
    }
  
    query += campos.join(', ');
    query += ', fecha_modificacion=NOW() ';
    query += `WHERE idusuario='${idusuario}'`;
  
    mysqlConeccion.query(query, (err, registros) => {
      if (!err) {
        respuesta.send(`Se ha actualizado el usuario con id ${idusuario}`);
      } else {
        console.log(err);
        respuesta.status(500).send('Ha ocurrido un error al actualizar el usuario');
      }
    });
  });
  


//////////////PEDIDOS//////////////
//////////////PEDIDOS//////////////  NO SE USA PORQUE ME EXPLOTO LA CABEZA
//////////////PEDIDOS//////////////

//MUESTRA LOS PEDIDOS DE UN USUARIO/CLIENTE
router.get('/pedidos/lista/:idusuario', (request, respuesta)=>{
    const {idusuario} = request.params;
    mysqlConeccion.query('SELECT pc.idpedidoC, pc.estado, pd.nombreproducto, pd.cantidad, pd.estado FROM usuarios u INNER JOIN usuario_cliente uc ON u.idusuario = uc.id_usuario INNER JOIN cliente c ON uc.id_cliente = c.idcliente INNER JOIN pedidos_cabecera pc ON c.idcliente = pc.id_cliente INNER JOIN pedidos_detalle pd ON pc.idpedidoC = pd.id_pedidoc INNER JOIN cliente_pedidoc_pedidod cpp ON c.idcliente = cpp.id_cliente AND pc.idpedidoC = cpp.id_pedidoc AND pd.idpedidod = cpp.id_pedidod WHERE u.idusuario = ?', [idusuario], (err, rows) => {
              
        if(!err){
            respuesta.json(rows);
        }else{
            console.log(err)
        }
    })
   
});


//PARA REALIZAR UN PEDIDO
router.post('/pedidos', (request, respuesta)=>{
    const { id_cliente } = request.body; // ID del cliente
    const { productos } = request.body; // Array de objetos con los detalles de los productos
    const estado = 'Pendiente'; // Estado inicial del pedido
    
    // Crear la cabecera del pedido en la tabla pedidos_cabecera
    const queryCabecera = `INSERT INTO pedidos_cabecera (estado, id_cliente) VALUES ('${estado}', ${id_cliente})`;
    mysqlConeccion.query(queryCabecera, (err, resultCabecera) => {
        if (err) {
            console.log(err);
            respuesta.status(500).json({ message: 'Error al crear la cabecera del pedido' });
        } else {
            const id_pedidoC = resultCabecera.insertId; // Obtener el ID del pedido creado
            let valuesDetalle = ''; // Valores para la inserción múltiple en la tabla pedidos_detalle
            
            // Recorrer el array de productos y armar los valores para la inserción múltiple en la tabla pedidos_detalle
            productos.forEach((producto) => {
                const { id_producto, nombreproducto, cantidad } = producto;
                const estado = 'Pendiente'; // Estado inicial del producto en el pedido
                valuesDetalle += `(${id_pedidoC}, ${id_producto}, '${nombreproducto}', ${cantidad}, '${estado}'),`;
            });
            valuesDetalle = valuesDetalle.slice(0, -1); // Eliminar la última coma
            
            // Insertar los detalles del pedido en la tabla pedidos_detalle
            const queryDetalle = `INSERT INTO pedidos_detalle (id_pedidoc, id_producto, nombreproducto, cantidad, estado) VALUES ${valuesDetalle}`;
            mysqlConeccion.query(queryDetalle, (err, resultDetalle) => {
                if (err) {
                    console.log(err);
                    respuesta.status(500).json({ message: 'Error al cargar los productos en el pedido' });
                } else {
                    respuesta.status(200).json({ message: 'Pedido creado con éxito' });
                }
            });
        }
    });
});


//////////////PEDIDOS//////////////
//////////////PEDIDOS//////////////  NO SE USA PORQUE ME EXPLOTO LA CABEZA
//////////////PEDIDOS//////////////





//////////////LOGIN DE USUARIO//////////////


router.post('/login', (request, respuesta)=>{
const{username, password}=request.body
if(username!=undefined && password!=undefined){
    mysqlConeccion.query('select usuarios.idusuario, usuarios.username, usuarios.password, usuarios.email, usuarios.apellido_nombre from usuarios where usuarios.estado="A" AND username=?', [username], (err, rows)=>{
    
        if(!err){  
            //contar la cantidad de registros que devuelve la base de datos 
            if(rows.length!=0){
                //aca se compara si el campo password de la base de datos pertenece a la palabra ingresada plana. (resultado true o false)
                const bcryptPassword = bcrypt.compareSync(password, rows[0].password);
                if(bcryptPassword){
                    jwt.sign({rows}, 'uliseskey', {expiresIn: '600s'}, (err, token)=>{
                        respuesta.json(
                            {
                                exito: true,
                                datos: rows,
                                token: token

                            });
                    })

                }else{
                    respuesta.json(
                        {
                            exito: false,
                            mensaje: "La contraseña es incorrecta"

                        });
                }

            }else{
                respuesta.json(
                    {
                        exito: false,
                        mensaje: "El usuario no existe"

                    });
                
            }   
        }else{
            respuesta.json(
                {
                    exito: false,
                    mensaje: 'Ocurrio un error en el servidor'

                });
            
        
        }
    });
}else{
    respuesta.json(
        {
            exito: false,
            mensaje: 'Falta completar datos'

        });
    
}

})

//REGISTRA UN NUEVO USUARIO

router.post('/registro', (request, respuesta)=>{
    const{username, password, email, apellido_nombre}=request.body

    let hash = bcrypt.hashSync(password,10);
    let query= `INSERT INTO usuarios (username, password, email, apellido_nombre,  fecha_creacion) VALUES ('${username}', '${hash}', '${email}', '${apellido_nombre}',  NOW() ) `;
    mysqlConeccion.query(query, (err, registros)=>{
        if(!err){
            
            respuesta.send("Se inserto correctamente nuestro usuario: "+username);
    
        }else{
            respuesta.send('Ocurrio un error en el servidor' +err);
            
        }
    })
    

//respuesta.send('Recibimos nuestro usuario: '+username+'y la contraseña: '+password);
})








//////////// FUNCION DE TOKEN DE SEGURIDAD ////////////

function verificarToken(request, respuesta, next){

    const BearerHeader= request.headers['authorization']
    if(typeof BearerHeader!=='undefined'){
        const bearerToken= BearerHeader.split(" ")[1]
        request.token=bearerToken;
        next();
    }else{
        respuesta.sendStatus(403);

    }
}



module.exports = router;