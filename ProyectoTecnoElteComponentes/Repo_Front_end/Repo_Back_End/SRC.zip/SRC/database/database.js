const mysql = require('mysql');

const mysqlConeccion = mysql.createConnection({
host: 'localhost',
user: 'root',
password: '1234',
database: 'tecnoelite',
});

mysqlConeccion.connect(function(err){
    if(err){
        console.log('Mi error es', err)
        return;
    }else{
        console.log('Mi coneccion se realizo correctamente')
    }
})

module.exports= mysqlConeccion;

