console.log('Hola soy un programa')

//
const operacion = require("./programa")
// LLamado al objeto operacion
operacion.sumar(4, 3)
