// Declaro la función sumar y paso como parametro 2 numeros
function sumar(num1, num2) {
    resultado = num1 + num2;
    console.log("La suma es: "+resultado)
    }
    // Declaró la explotación de la función
    module.exports = {
    "sumar": sumar
    }
    